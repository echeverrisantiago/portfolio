<div class="cta">
    <div class="cta-cont">
    <h1>Santiago Echeverri</h1>
    <h2>Desarrollador Web</h2>
    <p>Potencia los resultados de tu negocio mediante la presencia online
        <span class="line-caryn">
            <span class="bol-caryn"></span>
        </span>
    </p>
    <div class="cta-button"><i class="fa fa-phone"></i><span>Hablemos</span></div>
    </div>
    <div id="about-me">
    <img class="estilo" src="<?php echo get_template_directory_uri(); ?>/img/Elementos/Estilo.png">
    <i class="iconP aboutMeIcon"></i>
    <h2>Sobre mí</h2>
        <p>Me llamo Santiago Echeverri y me dedico al desarrollo web.</p>
        <p>Estoy altamente capacitado para brindarte la solución idónea para tu necesidad. He dedicado
            los últimos años de mi vida a la programación y tengo amplia experiencia en el sector.
        </p>
    </div>
    <img class="estilo" src="<?php echo get_template_directory_uri(); ?>/img/Elementos/Estilo.png">
</div>