<div class="line-caryncont">
    <span class="line-caryn"><span class="bol-caryn"></span></span>
</div>
<div class="portfolio">
   <div class="portafolio-txt">
    <h2>Portafolio</h2>
    <p>Proyectos en los que he trabajado</p>
    </div>
</div>
<div class="line-caryncont">
    <span class="line-caryn"><span class="bol-caryn"></span></span>
</div>