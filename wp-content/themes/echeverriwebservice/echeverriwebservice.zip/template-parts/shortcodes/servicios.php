<div id="servicios">
<div class="servicios-cont">
<h2 class="h2"data-aos="zoom-in">Servicios <span class="line-caryn"><span class="bol-caryn"></span></span> </h2>
<div data-aos="zoom-in" class="servicios-container">
    <div class="servicio-item">
    <i class="iconP consSitios"></i>
        <h2>Construcción de sitios</h2>
        <p>Accede al mercado digital mediante tu propio sitio web. Llega a más personas
            con el posicionamiento web y administra tu información con mayor facilidad.
        </p>
    </div><div class="servicio-item">
    <i class="iconP manteWeb"></i>
        <h2>Mantenimiento web</h2>
        <p>Recibe constantes cambios de administración en tu sitio.<br>
        Nota: Solo aplica sitios desarrollados por
        </p>
    </div><div class="servicio-item">
    <i class="iconP renoSitios"></i>
        <h2>Renovación de sitios</h2>
        <p>Mejora la imágen de tu empresa o tu marca con una interfáz moderna y los últimos estándarez
            de tecnología
        </p>
    </div><div class="servicio-item">
    <i class="iconP iconSEO"></i>
        <h2>SEO</h2>
        <p>Adquiere una mejora apareciendo en los primeros resultados de los motores de búsqueda.<br>
        Nota: Solo aplica sitios desarrollados por
        </p>
    </div>
</div>
</div>
<h2 class="h2"> <span class="line-caryn"><span class="bol-caryn"></span></span> </h2>
</div>