<div id="beneficios">
    <h2 class="h2">Beneficios</h2>
    <div class="beneficios-cont">
        <div class="beneficios">
            <div class="beneficio-item item-active">
                <i class="iconP beneIcons itemBeneActive  seguridadIcon"></i>
                <h2 class="title-beneficio">Seguridad</h2>
            </div>
            <div class="beneficio-item">
                <i class="iconP beneIcons  responsiveIcon"></i>
                <h2 class="title-beneficio">Responsive</h2>
            </div>
            <div class="beneficio-item">
                <i class="iconP beneIcons  visibilidadIcon"></i>
                <h2 class="title-beneficio">Visibilidad digital</h2>
            </div>
            <div class="beneficio-item">
                <i class="iconP beneIcons  administrableIcon"></i>
                <h2 class="title-beneficio">Sitios administrables</h2>
            </div>
            <div class="beneficio-item">
                <i class="iconP beneIcons  optimizacionIcon"></i>
                <h2 class="title-beneficio">Optimización de carga</h2>
            </div>
        </div>
        <div class="beneficio-detail">
        <i class="iconP seguridadIconActive"></i>
        <h2 class="title-beneficio title-detail">Seguridad</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
             Aliquid cum eos reiciendis molestias necessitatibus quae
              dolor adipisci autem consequuntur ullam, iure laboriosam
              enim laborum consectetur obcaecati impedit doloremque maxime. Perferendis.</p>
        </div>
    </div>
</div>
<div class="line-caryncont">
    <span class="line-caryn"><span class="bol-caryn"></span></span>
</div>