<div id="social">
    <a href=""><img src="<?php echo get_template_directory_uri(); ?>/img/Elementos/26.png"></a>
    <a href="https://api.whatsapp.com/send?phone=573145797888" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/img/Elementos/27.png"></a>
    <a href="mailto:info@echeverriwebservice.com"><img src="<?php echo get_template_directory_uri(); ?>/img/Elementos/28.png"></a>
</div>